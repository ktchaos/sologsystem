% FATOS:
%

corpoceleste(mercurio).
corpoceleste(venus).
corpoceleste(terra).
corpoceleste(marte).
corpoceleste(jupiter).
corpoceleste(saturno).
corpoceleste(urano).
corpoceleste(netuno).

anterioreproximo(mercurio, venus, terra).
anterioreproximo(venus, terra, marte).
anterioreproximo(terra, marte, jupiter).
anterioreproximo(marte, jupiter, saturno).
anterioreproximo(jupiter, saturno, urano).
anterioreproximo(saturno, urano, netuno).

corpoceleste(lua).
corpoceleste(fobos).
corpoceleste(deimos).
corpoceleste(io).
corpoceleste(europa).
corpoceleste(ganimedes).
corpoceleste(calisto).
corpoceleste(mimas).
corpoceleste(encelado).
corpoceleste(tetis).
corpoceleste(dione).
corpoceleste(reia).
corpoceleste(tita).
corpoceleste(japeto).
corpoceleste(miranda).
corpoceleste(ariel).
corpoceleste(umbriel).
corpoceleste(titania).
corpoceleste(oberon).
corpoceleste(proteu).
corpoceleste(tritao).

corpoceleste(2004/fh).
corpoceleste(2004/fu162).

corpoceleste(apophis).
corpoceleste(4-vesta).
corpoceleste(2-palas).
corpoceleste(1-ceres).
corpoceleste(7-iris).
corpoceleste(433-eros).
corpoceleste(6-hebe).
corpoceleste(6-juno).
corpoceleste(18-melpomene).
corpoceleste(15-eunomia).
corpoceleste(8-flora).
corpoceleste(324-bamberga).
corpoceleste(ganymed).
corpoceleste(9-metis).
corpoceleste(192-nausikaa).
corpoceleste(20-massalia).

corpoceleste(10-higia).
corpoceleste(31-euphrosyne).
corpoceleste(704-interamnia).
corpoceleste(511-davida).
corpoceleste(532-herculina).
corpoceleste(16-psique).
corpoceleste(52-europa).
corpoceleste(88-thisbe).
corpoceleste(13-egeria).
corpoceleste(423-diotima).
corpoceleste(29-amphitrite).
corpoceleste(87-sylvia).
corpoceleste(48-doris).

corpoceleste(plutao).
corpoceleste(eris).
corpoceleste(make-make).
corpoceleste(haumea).

orbitasol(mercurio).
orbitasol(venus).
orbitasol(terra).
orbitasol(marte).
orbitasol(jupiter).
orbitasol(saturno).
orbitasol(urano).
orbitasol(netuno).

orbitasol(um-ceres).
orbitasol(plutao).
orbitasol(eris).
orbitasol(make-make).
orbitasol(haumea).

massasuficiente(mercurio).
massasuficiente(venus).
massasuficiente(terra).
massasuficiente(marte).
massasuficiente(jupiter).
massasuficiente(saturno).
massasuficiente(urano).
massasuficiente(netuno).

orbitaplaneta(lua, terra).
orbitaplaneta(fobos, marte).
orbitaplaneta(deimos, marte).
orbitaplaneta(io, jupiter).
orbitaplaneta(europa, jupiter).
orbitaplaneta(ganimedes, jupiter).
orbitaplaneta(calisto, jupiter).
orbitaplaneta(mimas, saturno).
orbitaplaneta(encelado, saturno).
orbitaplaneta(tetis, saturno).
orbitaplaneta(dione, saturno).
orbitaplaneta(reia, saturno).
orbitaplaneta(tita, saturno).
orbitaplaneta(japeto, saturno).
orbitaplaneta(miranda, urano).
orbitaplaneta(ariel, urano).
orbitaplaneta(umbriel, urano).
orbitaplaneta(titania, urano).
orbitaplaneta(oberon, urano).
orbitaplaneta(proteu, netuno).
orbitaplaneta(tritao, netuno).

intersectaterra(2004/fh).
intersectaterra(2004/fu162).

rochoso(apophis).
rochoso(4-vesta).
rochoso(2-palas).
rochoso(1-ceres).
rochoso(7-iris).
rochoso(433-eros).
rochoso(6-hebe).
rochoso(3-juno).
rochoso(18-melpomene).
rochoso(15-eunomia).
rochoso(8-flora).
rochoso(324-bamberga).
rochoso(ganymed).
rochoso(9-metis).
rochoso(192-nausikaa).
rochoso(20-massalia).

rochoso(10-higia).
rochoso(31-euphrosyne).
rochoso(704-interamnia).
rochoso(511-davida).
rochoso(532-herculina).
rochoso(16-psique).
rochoso(52-europa).
rochoso(88-thisbe).
rochoso(13-egeria).
rochoso(423-diotima).
rochoso(29-amphitrite).
rochoso(87-sylvia).
rochoso(48-doris).

altamagnitude(apophis).
altamagnitude(4-vesta).
altamagnitude(2-palas).
altamagnitude(1-ceres).
altamagnitude(7-iris).
altamagnitude(433-eros).
altamagnitude(6-hebe).
altamagnitude(3-juno).
altamagnitude(18-melpomene).
altamagnitude(15-eunomia).
altamagnitude(8-flora).
altamagnitude(324-bamberga).
altamagnitude(ganymed).
altamagnitude(9-metis).
altamagnitude(192-nausikaa).
altamagnitude(20-massalia).

perturba(4-vesta, marte).
perturba(2-palas, marte).
perturba(1-ceres, marte).
perturba(7-iris, marte).
perturba(3-juno, marte).
perturba(15-eunomia, marte).
perturba(10-higia, marte).
perturba(31-euphrosyne, marte).
perturba(704-interamnia, marte).
perturba(511-davida, marte).
perturba(532-herculina, marte).
perturba(16-psique, marte).
perturba(52-europa, marte).
perturba(88-thisbe, marte).
perturba(13-egeria, marte).
perturba(423-diotima, marte).
perturba(29-amphitrite, marte).
perturba(87-sylvia, marte).
perturba(48-doris, marte).

satelite(lua).
satelite(fobos).
satelite(deimos).
satelite(io).
satelite(europa).
satelite(ganimedes).
satelite(calisto).
satelite(mimas).
satelite(encelado).
satelite(tetis).
satelite(dione).
satelite(reia).
satelite(tita).
satelite(japeto).
satelite(miranda).
satelite(ariel).
satelite(umbriel).
satelite(titania).
satelite(oberon).
satelite(proteu).
satelite(tritao).



% PREDICADOS:

planeta(X) :-
    corpoceleste(X), orbitasol(X), massasuficiente(X).

satelitenatural(X, Y) :-
    satelite(X), orbitaplaneta(X, Y).

neo(X) :-
    corpoceleste(X), intersectaterra(X).

asteroide(X) :-
    corpoceleste(X), rochoso(X).

asteroidevistodaterra(X) :-
    asteroide(X), altamagnitude(X).

asteroidemassivo(X) :-
    asteroide(X), perturba(X, marte).

pertencecinturao(X) :-
    asteroide(X).

planetaanao(X) :-
    corpoceleste(X), orbitasol(X), \+ satelite(X), \+ planeta(X).

planetasproximos(X, Y, Z) :-
    planeta(X), planeta(Y), planeta(Z), anterioreproximo(X, Y, Z).

planetapertenceaosistema(P) :-
    planeta(P), member(P, [mercurio, venus, terra, marte, jupiter, saturno, urano, netuno]).





























